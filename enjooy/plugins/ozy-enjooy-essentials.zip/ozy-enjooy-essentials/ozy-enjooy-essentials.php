<?php
/**
 * Plugin Name: ozythemes Enjooy Theme Essentials
 * Plugin URI: http://themeforest.net/user/freevision/portfolio
 * Description: This plugin will enable Custom Post types like Portfolio, Categorized Image Gallery and few other features for your ENJOOY theme.
 * Version: 1.0
 * Author: freevision
 */

define( 'OZY_ENJOOY_ESSENTIALS_ACTIVATED', 1 );

/**
 * Custom post types for portfolio and video gallery
 */
function ozy_plugin_create_post_types() {
	
	load_plugin_textdomain('vp_textdomain', false, basename( dirname( __FILE__ ) ) . '/translate');
	
	$essentials_options = get_option('ozy_enjooy_essentials');
	if(is_array($essentials_options) && isset($essentials_options['portfolio_slug'])) {
		$portfolio_slug = $essentials_options['portfolio_slug'];
	} else {
		$portfolio_slug = 'portfolio';
	}
	/*if(is_array($essentials_options) && isset($essentials_options['video_gallery_slug'])) {
		$video_gallery_slug = $essentials_options['video_gallery_slug'];
	} else {
		$video_gallery_slug = 'video';
	}*/
	
	if(is_array($essentials_options) && isset($essentials_options['image_gallery_slug'])) {
		$image_gallery_slug = $essentials_options['image_gallery_slug'];
	} else {
		$image_gallery_slug = 'gallery';
	}	
	
	//Portfolio
	register_post_type( 'ozy_portfolio',
		array(
			'labels' => array(
				'name' => __( 'Portfolio', 'vp_textdomain'),
				'singular_name' => __( 'Portfolio', 'vp_textdomain'),
				'add_new' => __( 'Add Portfolio Item', 'vp_textdomain'),
				'edit_item' => __( 'Edit Portfolio Item', 'vp_textdomain'),
				'new_item' => __( 'New Portfolio Item', 'vp_textdomain'),
				'view_item' => __( 'View Portfolio Item', 'vp_textdomain'),
				'search_items' => __( 'Search Portfolio Items', 'vp_textdomain'),
				'not_found' => __( 'No Portfolio Items found', 'vp_textdomain'),
				'not_found_in_trash' => __( 'No Portfolio Items found in Trash', 'vp_textdomain')				
			),
			'can_export' => true,
			'public' => true,
			'sort' => true,
			'has_archive' => true,
			'rewrite' => array('slug' => $portfolio_slug, 'with_front' => true),
			'supports' => array('title','editor','thumbnail','excerpt','page-attributes','comments'),
			'menu_icon' => 'dashicons-portfolio'
		)
	);
	
	//Video Gallery
	/*register_post_type( 'ozy_video',
		array(
			'labels' => array(
				'name' => __( 'Video Gallery', 'vp_textdomain'),
				'singular_name' => __( 'Video Gallery', 'vp_textdomain'),
				'add_new' => __( 'Add Video Gallery Item', 'vp_textdomain'),
				'edit_item' => __( 'Edit Video Gallery Item', 'vp_textdomain'),
				'new_item' => __( 'New Video Gallery Item', 'vp_textdomain'),
				'view_item' => __( 'View Video Gallery Item', 'vp_textdomain'),
				'search_items' => __( 'Search Video Gallery Items', 'vp_textdomain'),
				'not_found' => __( 'No Video Gallery Items found', 'vp_textdomain'),
				'not_found_in_trash' => __( 'No Video Gallery Items found in Trash', 'vp_textdomain')				
			),
			'can_export' => true,
			'public' => true,
			'sort' => true,
			'has_archive' => true,
			'rewrite' => array('slug' => $video_gallery_slug, 'with_front' => true),
			'supports' => array('title','thumbnail','page-attributes'),
			'menu_icon' => 'dashicons-video-alt'
		)
	);*/
	
	//Image Gallery
	register_post_type( 'ozy_gallery',
		array(
			'labels' => array(
				'name' => __( 'Image Gallery', 'vp_textdomain'),
				'singular_name' => __( 'Image Gallery', 'vp_textdomain'),
				'add_new' => __( 'Add Image Gallery Item', 'vp_textdomain'),
				'edit_item' => __( 'Edit Image Gallery Item', 'vp_textdomain'),
				'new_item' => __( 'New Image Gallery Item', 'vp_textdomain'),
				'view_item' => __( 'View Image Gallery Item', 'vp_textdomain'),
				'search_items' => __( 'Search Image Gallery Items', 'vp_textdomain'),
				'not_found' => __( 'No Image Gallery Items found', 'vp_textdomain'),
				'not_found_in_trash' => __( 'No Image Gallery Items found in Trash', 'vp_textdomain')				
			),
			'can_export' => true,
			'public' => true,
			'sort' => true,
			'has_archive' => true,
			'rewrite' => array('slug' => $image_gallery_slug, 'with_front' => true),
			'supports' => array('title','thumbnail', 'excerpt'),
			'menu_icon' => 'dashicons-format-gallery'
		)
	);		
}
add_action( 'init', 'ozy_plugin_create_post_types', 0 );


/**
* ozy_insert_bulk_posts
*
* Like button handling function. Parameters passed by POST
*/
function ozy_insert_bulk_posts() {
	global $user_ID;

	if ( !current_user_can( 'publish_posts' ) )  {
		wp_die( __( 'You do not have sufficient permissions to access this page.', 'vp_textdomain' ) );
	}
	
	$data_back = json_decode (stripslashes($_POST['posts']), true);
	
	foreach($data_back as $p) {
		if(isset($p['aid']) && isset($p['description']) && isset($p['title'])) {
			$new_post = array(
				'post_title' => sanitize_text_field($p['title']),
				'post_excerpt' => sanitize_text_field($p['description']),
				'post_status' => 'publish',
				'post_date' => date('Y-m-d H:i:s'),
				'post_author' => $user_ID,
				'post_type' => 'ozy_gallery',
				'post_category' => array(0),
				'tax_input' => array('image_gallery_category' => explode(',', $p['category']))
			);
			add_post_meta(wp_insert_post($new_post), '_thumbnail_id', sanitize_text_field($p['aid']), true);
			//https://codex.wordpress.org/Function_Reference/wp_insert_post
		}
	}
	wp_die( __( 'Posts successfully created!', 'vp_textdomain' ) );
}
add_action( 'wp_ajax_ozy_insert_bulk_posts', 'ozy_insert_bulk_posts' ); 

function ozy_bulk_post_menu() {
	add_submenu_page( 'edit.php?post_type=ozy_gallery', 'Bulk Posts', 'Create Bulk Posts', 'publish_posts', 'ozy_gallery_bulk_post', 'ozy_bulk_post_page');
}
add_action( 'admin_menu', 'ozy_bulk_post_menu' );

function ozy_bulk_post_page() {
	wp_enqueue_media();
	wp_enqueue_script('ozy-bulk-editor', plugin_dir_url( __FILE__ ) . 'js/scripts.js', array('jquery'), null, true );	
	wp_localize_script( 'ozy-bulk-editor', 'ozyBulkEditor', array('ozyAdminAjaxUrl' => admin_url('admin-ajax.php') ));
	wp_enqueue_style('ozy-bulk-editor', plugin_dir_url( __FILE__ ) . 'css/style.css');
	
	if ( !current_user_can( 'publish_posts' ) )  {
		wp_die( __( 'You do not have sufficient permissions to access this page.' ) );
	}
	echo '<div id="ozy_bulk_post_editor_wrapper" class="wrap">';
	echo '<h2>'. __('Create Bulk Posts', 'vp_textdomain') . '</h2>';
	echo '<p>'. __('1 - Select / Upload Images', 'vp_textdomain') . '</p>';
	echo '<p>'. __('2 - Make changes on Title and Description field if you want', 'vp_textdomain') . '</p>';
	echo '<p>'. __('3 - Hit "Create Posts" button', 'vp_textdomain') . '</p>';
	echo '<p>'. __('4 - <strong>Enjoy!</strong>', 'vp_textdomain') . '</p>';
	echo '<p>'. __('* You can make multiple image selection.', 'vp_textdomain') . '</p>';
	echo '<p>'. __('** Once you upload multiple image files to your server, all will be checked as default, simply hit "Select" button on your media manager window', 'vp_textdomain') . '</p>';
	echo '<input type="button" id="upload_image_button" value="Select / Upload Images" class="button-primary">';
	
	echo '<div class="wrap">';
	echo '<h4>'. __('Please select related categories for your gallery posts', 'vp_textdomain') . '</h4>';
	$cat_arr = get_terms( 'image_gallery_category', array('hide_empty' => false ));
	foreach ($cat_arr as $item) {
		if(isset($item->name) && $item->term_id) {
			echo '<input type="checkbox" value="'. $item->term_id .'" name="ozy_bulk_post_editor_category" id="ozy_bulk_post_editor_category_'. $item->term_id .'"><label for="ozy_bulk_post_editor_category_'. $item->term_id .'">'. $item->name .'</label>&nbsp;&nbsp;';
		}
	}
	echo '</div>';
	
	$OzyEmptyListTable = new Ozy_Empty_List_Table();
	echo '<div id="ozy_bulk_post_editor">';
	$OzyEmptyListTable->prepare_items(); 
	$OzyEmptyListTable->display(); 	
	echo '</div>';
	
	echo '<input type="button" id="ozy_bulk_post_editor_create_posts" value="Create Posts" class="button-primary">';		
	echo '<div id="ozy_bulk_post_editor_thumb"></div>';	
	echo '<div id="ozy_bulk_post_editor_loader"><span>'. __('Working... Please wait.', 'vp_textdomain') .'</span></div>';	
	echo '</div>';
}

if(!class_exists('WP_List_Table')){
	require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}
class Ozy_Empty_List_Table extends WP_List_Table {
	function get_columns(){
		$columns = array(
			'filename' 		=> 'File Name',
			'title'    		=> 'Title',
			'description'   => 'Description'
		);
		return $columns;
	}

	function prepare_items() {
		$columns = $this->get_columns();
		$hidden = array();
		$sortable = array();
		$this->_column_headers = array($columns, $hidden, $sortable);
	}

	function column_default( $item, $column_name ) {
		switch( $column_name ) { 
			case 'filename':
			case 'title':
			case 'description':
				return $item[ $column_name ];
			default:
				return print_r( $item, true ) ; //Show the whole array for troubleshooting purposes
		}
	}
}

/**
 * Custom taxonomy registration
 */
function ozy_plugin_create_custom_taxonomies()
{
	//Portfolio Categories
	$labels = array(
		'name' => __( 'Portfolio Categories', 'vp_textdomain' ),
		'singular_name' => __( 'Portfolio Category', 'vp_textdomain' ),
		'search_items' =>  __( 'Search Portfolio Categories', 'vp_textdomain' ),
		'popular_items' => __( 'Popular Portfolio Categories', 'vp_textdomain' ),
		'all_items' => __( 'All Portfolio Categories', 'vp_textdomain' ),
		'parent_item' => __( 'Parent Portfolio Categories', 'vp_textdomain' ),
		'parent_item_colon' => __( 'Parent Portfolio Category:', 'vp_textdomain' ),
		'edit_item' => __( 'Edit Portfolio Category', 'vp_textdomain' ),
		'update_item' => __( 'Update Portfolio Category', 'vp_textdomain' ),
		'add_new_item' => __( 'Add New Portfolio Category', 'vp_textdomain' ),
		'new_item_name' => __( 'New Portfolio Category', 'vp_textdomain' ),
	);
	
	register_taxonomy('portfolio_category', array('ozy_portfolio'), array(
		'hierarchical' => true,
		'labels' => $labels,
		'show_ui' => true,
		'query_var' => true,
		'sort' => true,
		'rewrite' => array( 'slug' => 'portfolio_category' ),
	));
	
	//Video Gallery Categories
	/*$labels = array(
		'name' => __( 'Video Gallery Categories', 'vp_textdomain' ),
		'singular_name' => __( 'Video Gallery Category', 'vp_textdomain' ),
		'search_items' =>  __( 'Search Video Gallery Categories', 'vp_textdomain' ),
		'popular_items' => __( 'Popular Video Gallery Categories', 'vp_textdomain' ),
		'all_items' => __( 'All Video Gallery Categories', 'vp_textdomain' ),
		'parent_item' => __( 'Parent Video Gallery Categories', 'vp_textdomain' ),
		'parent_item_colon' => __( 'Parent Video Gallery Category:', 'vp_textdomain' ),
		'edit_item' => __( 'Edit Video Gallery Category', 'vp_textdomain' ),
		'update_item' => __( 'Update Video Gallery Category', 'vp_textdomain' ),
		'add_new_item' => __( 'Add New Video Gallery Category', 'vp_textdomain' ),
		'new_item_name' => __( 'New Video Gallery Category', 'vp_textdomain' ),
	);
	
	register_taxonomy('video_gallery_category', array('ozy_video'), array(
		'hierarchical' => true,
		'labels' => $labels,
		'show_ui' => true,
		'query_var' => true,
		'sort' => true,
		'rewrite' => array( 'slug' => 'video_gallery_category' ),
	));*/
	
	//Image Gallery Categories
	/*$labels = array(
		'name' => __( 'Image Gallery Categories', 'vp_textdomain' ),
		'singular_name' => __( 'Image Gallery Category', 'vp_textdomain' ),
		'search_items' =>  __( 'Search Image Gallery Categories', 'vp_textdomain' ),
		'popular_items' => __( 'Popular Image Gallery Categories', 'vp_textdomain' ),
		'all_items' => __( 'All Image Gallery Categories', 'vp_textdomain' ),
		'parent_item' => __( 'Parent Image Gallery Categories', 'vp_textdomain' ),
		'parent_item_colon' => __( 'Parent Image Gallery Category:', 'vp_textdomain' ),
		'edit_item' => __( 'Edit Image Gallery Category', 'vp_textdomain' ),
		'update_item' => __( 'Update Image Gallery Category', 'vp_textdomain' ),
		'add_new_item' => __( 'Add New Image Gallery Category', 'vp_textdomain' ),
		'new_item_name' => __( 'New Image Gallery Category', 'vp_textdomain' ),
	);
	
	register_taxonomy('image_gallery_category', array('ozy_gallery'), array(
		'hierarchical' => true,
		'labels' => $labels,
		'show_ui' => true,
		'query_var' => true,
		'sort' => true,
		'rewrite' => array( 'slug' => 'image_gallery_category' ),
	));*/
	
	//Image Gallery Categories
	$labels = array(
		'name' => __( 'Image Gallery Categories', 'vp_textdomain' ),
		'singular_name' => __( 'Image Gallery Category', 'vp_textdomain' ),
		'search_items' =>  __( 'Search Image Gallery Categories', 'vp_textdomain' ),
		'popular_items' => __( 'Popular Image Gallery Categories', 'vp_textdomain' ),
		'all_items' => __( 'All Image Gallery Categories', 'vp_textdomain' ),
		'parent_item' => __( 'Parent Image Gallery Categories', 'vp_textdomain' ),
		'parent_item_colon' => __( 'Parent Image Gallery Category:', 'vp_textdomain' ),
		'edit_item' => __( 'Edit Image Gallery Category', 'vp_textdomain' ),
		'update_item' => __( 'Update Image Gallery Category', 'vp_textdomain' ),
		'add_new_item' => __( 'Add New Image Gallery Category', 'vp_textdomain' ),
		'new_item_name' => __( 'New Image Gallery Category', 'vp_textdomain' ),
	);
	
	register_taxonomy('image_gallery_category', array('ozy_gallery'), array(
		'hierarchical' => true,
		'labels' => $labels,
		'show_ui' => true,
		'query_var' => true,
		'sort' => true,
		'rewrite' => array( 'slug' => 'image_gallery_category' ),
	));	
}
add_action( 'init', 'ozy_plugin_create_custom_taxonomies', 0 );

/**
 * Options panel for this plugin
 */
class OzyEssentialsOptionsPage_Enjooy
{
    /**
     * Holds the values to be used in the fields callbacks
     */
    private $options;

    /**
     * Start up
     */
    public function __construct()
    {
        add_action( 'admin_menu', array( $this, 'add_plugin_page' ) );
        add_action( 'admin_init', array( $this, 'page_init' ) );
    }

    /**
     * Add options page
     */
    public function add_plugin_page()
    {
        // This page will be under "Settings"
        add_options_page(
            'Settings Admin', 
            'ozy Essentials', 
            'manage_options', 
            'ozy-enjooy-essentials-setting-admin', 
            array( $this, 'create_admin_page' )
        );
    }

    /**
     * Options page callback
     */
    public function create_admin_page()
    {
        // Set class property
        $this->options = get_option( 'ozy_enjooy_essentials' );
        ?>
        <div class="wrap">
            <?php screen_icon(); ?>
            <h2>ozy Essentials Options</h2>           
            <form method="post" action="options.php">
            <?php
                // This prints out all hidden setting fields
                settings_fields( 'ozy_enjooy_essentials_option_group' );
                do_settings_sections( 'ozy-enjooy-essentials-setting-admin' );
				do_settings_sections( 'ozy-enjooy-essentials-setting-admin-twitter' );
			
                submit_button(); 
            ?>
            </form>
        </div>
        <?php
    }

    /**
     * Register and add settings
     */
    public function page_init()
    {        
        register_setting(
            'ozy_enjooy_essentials_option_group', // Option group
            'ozy_enjooy_essentials', // Option name
            array( $this, 'sanitize' ) // Sanitize
        );

        add_settings_section(
            'ozy-enjooy-essentials-setting-admin', // ID
            'Options', // Title
            array( $this, 'print_section_info' ), // Callback
            'ozy-enjooy-essentials-setting-admin' // Page
        );

        add_settings_field(
            'portfolio_slug', 
            'Portfolio Slug Name', 
            array( $this, 'field_callback' ), 
            'ozy-enjooy-essentials-setting-admin', 
            'ozy-enjooy-essentials-setting-admin'
        );
		
        /*add_settings_field(
            'video_gallery_slug', 
            'Video Gallery Slug Name', 
            array( $this, 'field_callback_video_gallery_slug' ), 
            'ozy-enjooy-essentials-setting-admin', 
            'ozy-enjooy-essentials-setting-admin'
        );*/
		
        add_settings_field(
            'image_gallery_slug', 
            'Image Gallery Slug Name', 
            array( $this, 'field_callback_image_gallery_slug' ), 
            'ozy-enjooy-essentials-setting-admin', 
            'ozy-enjooy-essentials-setting-admin'
        );			
		
        add_settings_section(
            'ozy-enjooy-essentials-setting-admin-twitter', 
            'Twitter Parameters', 
            array( $this, 'print_twitter_section_info' ),
            'ozy-enjooy-essentials-setting-admin-twitter'
        );		
		
        add_settings_field(
            'twitter_consumer_key', 
            'Consumer Key', 
            array( $this, 'field_callback_twitter_consumer_key' ), 
            'ozy-enjooy-essentials-setting-admin-twitter', 
            'ozy-enjooy-essentials-setting-admin-twitter'
        );

		add_settings_field(
            'twitter_secret_key', 
            'Secret Key', 
            array( $this, 'field_callback_twitter_secret_key' ), 
            'ozy-enjooy-essentials-setting-admin-twitter', 
            'ozy-enjooy-essentials-setting-admin-twitter'
        );
		
		add_settings_field(
            'twitter_token_key', 
            'Access Token Key', 
            array( $this, 'field_callback_twitter_token_key' ), 
            'ozy-enjooy-essentials-setting-admin-twitter', 
            'ozy-enjooy-essentials-setting-admin-twitter'
        );
		
		add_settings_field(
            'twitter_token_secret_key', 
            'Access Token Secret Key', 
            array( $this, 'field_callback_twitter_token_secret_key' ), 
            'ozy-enjooy-essentials-setting-admin-twitter', 
            'ozy-enjooy-essentials-setting-admin-twitter'
        );		

    }

    /**
     * Sanitize each setting field as needed
     *
     * @param array $input Contains all settings fields as array keys
     */
    public function sanitize( $input )
    {
        if( !empty( $input['portfolio_slug'] ) )
            $input['portfolio_slug'] = sanitize_text_field( $input['portfolio_slug'] );

	    /*if( !empty( $input['video_gallery_slug'] ) )
            $input['video_gallery_slug'] = sanitize_text_field( $input['video_gallery_slug'] );*/

	    if( !empty( $input['image_gallery_slug'] ) )
            $input['image_gallery_slug'] = sanitize_text_field( $input['image_gallery_slug'] );

		if( !empty( $input['twitter_consumer_key'] ) )
            $input['twitter_consumer_key'] = sanitize_text_field( $input['twitter_consumer_key'] );

		if( !empty( $input['twitter_secret_key'] ) )
            $input['twitter_secret_key'] = sanitize_text_field( $input['twitter_secret_key'] );

        if( !empty( $input['twitter_token_key'] ) )
            $input['twitter_token_key'] = sanitize_text_field( $input['twitter_token_key'] );

        if( !empty( $input['twitter_token_secret_key'] ) )
            $input['twitter_token_secret_key'] = sanitize_text_field( $input['twitter_token_secret_key'] );			
			
        /*if( !is_numeric( $input['ozy_shortcodes'] ) )
            $input['ozy_shortcodes'] = '1';*/

        return $input;
    }

    /** 
     * Print the Section text
     */
    public function print_section_info()
    {
        print 'If you want your portfolio, video gallery and image gallery post types to have a custom slug in the url, please enter it here.
		<p><strong>You will still have to refresh your permalinks after saving this!</strong>
		<br>This is done by going to Settings > Permalinks and clicking save.</p>';
    }
	
    public function print_twitter_section_info()
    {
        print 'Enter required parameters of your Twitter Dev. account <a href="https://dev.twitter.com/apps" target="_blank">https://dev.twitter.com/apps</a>';
    }	

    /** 
     * Get the settings option array and print one of its values : Portfolio Slug
     */
    public function field_callback()
    {
        printf(
            '<input type="text" id="portfolio_slug" name="ozy_enjooy_essentials[portfolio_slug]" value="%s" />',
            (!isset($this->options['portfolio_slug']) ? 'portfolio' : esc_attr( $this->options['portfolio_slug']))
        );
    }

    /** 
     * Get the settings option array and print one of its values : Video Gallery Slug
     */
    /*public function field_callback_video_gallery_slug()
    {
        printf(
            '<input type="text" id="video_gallery_slug" name="ozy_enjooy_essentials[video_gallery_slug]" value="%s" />',
            (!isset($this->options['video_gallery_slug']) ? 'video' : esc_attr( $this->options['video_gallery_slug']))
        );
    }*/	
	
    /** 
     * Get the settings option array and print one of its values : Image Gallery Slug
     */
    public function field_callback_image_gallery_slug()
    {
        printf(
            '<input type="text" id="image_gallery_slug" name="ozy_enjooy_essentials[image_gallery_slug]" value="%s" />',
            (!isset($this->options['image_gallery_slug']) ? 'gallery' : esc_attr( $this->options['image_gallery_slug']))
        );
    }		
	
    /** 
     * Get the settings option array and print one of its values : Twitter Consumer Key
     */	
    public function field_callback_twitter_consumer_key()
    {
        printf(
            '<input type="text" id="twitter_consumer_key" name="ozy_enjooy_essentials[twitter_consumer_key]" value="%s" />',
            (!isset($this->options['twitter_consumer_key']) ? '' : esc_attr( $this->options['twitter_consumer_key']))
        );
    }

    /** 
     * Get the settings option array and print one of its values : Twitter Secret Key
     */	
    public function field_callback_twitter_secret_key()
    {
        printf(
            '<input type="text" id="twitter_secret_key" name="ozy_enjooy_essentials[twitter_secret_key]" value="%s" />',
            (!isset($this->options['twitter_secret_key']) ? '' : esc_attr( $this->options['twitter_secret_key']))
        );		
    }

    /** 
     * Get the settings option array and print one of its values : Twitter Token Key
     */	
    public function field_callback_twitter_token_key()
    {
        printf(
            '<input type="text" id="twitter_token_key" name="ozy_enjooy_essentials[twitter_token_key]" value="%s" />',
            (!isset($this->options['twitter_token_key']) ? '' : esc_attr( $this->options['twitter_token_key']))
        );		
    }

    /** 
     * Get the settings option array and print one of its values : Twitter Token Secret Key
     */
    public function field_callback_twitter_token_secret_key()
    {
        printf(
            '<input type="text" id="twitter_token_secret_key" name="ozy_enjooy_essentials[twitter_token_secret_key]" value="%s" />',
            (!isset($this->options['twitter_token_secret_key']) ? '' : esc_attr( $this->options['twitter_token_secret_key']))
        );		
    }

}

/** 
 * Register activation redirection
 */
register_activation_hook(__FILE__, 'ozy_essentials_plugin_activate');
add_action('admin_init', 'ozy_essentials_plugin_activate_redirect');

function ozy_essentials_plugin_activate() {
    add_option('ozy_essentials_plugin_activate_redirect', true);
}

function ozy_essentials_plugin_activate_redirect() {
    if (get_option('ozy_essentials_plugin_activate_redirect', false)) {
        delete_option('ozy_essentials_plugin_activate_redirect');
        wp_redirect('options-general.php?page=ozy-enjooy-essentials-setting-admin');
    }
}

/**
 * We need this plugin to work only on admin side
 */

if( is_admin() ) {
    $ozy_essentials_options_page = new OzyEssentialsOptionsPage_Enjooy();
}