jQuery( function ( $ )
{
	$( '.mb-tooltip' ).tooltip();
} );
